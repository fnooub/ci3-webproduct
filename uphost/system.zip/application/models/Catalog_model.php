<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 28-Dec-16
 * Time: 9:10 PM
 */
class catalog_model extends MY_Model
{
    var $table  = 'catalog';
}