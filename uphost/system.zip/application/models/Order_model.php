<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 14-Jan-17
 * Time: 3:18 PM
 */
class Order_model extends MY_Model
{
    var $table  = 'order';
}