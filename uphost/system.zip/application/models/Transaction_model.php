<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 14-Jan-17
 * Time: 3:14 PM
 */
class Transaction_model extends MY_Model
{
    var $table  = 'transaction';
}