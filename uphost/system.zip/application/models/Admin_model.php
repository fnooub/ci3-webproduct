<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 23-Dec-16
 * Time: 10:33 PM
 */
class admin_model extends MY_Model
{
    var $table  = 'admin';
}