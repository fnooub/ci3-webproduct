<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 06-Jan-17
 * Time: 8:22 PM
 */
class News_model extends MY_Model
{
    var $table  = 'news';
}