<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 06-Jan-17
 * Time: 9:50 PM
 */
class Slide_model extends MY_Model
{
    var $table  = 'slide';
}