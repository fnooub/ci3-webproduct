<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 29-Dec-16
 * Time: 8:30 PM
 */
class Product_model extends MY_Model
{
    var $table  = 'product';
}