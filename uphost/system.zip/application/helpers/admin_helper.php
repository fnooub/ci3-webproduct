<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 25-Dec-16
 * Time: 1:33 PM
 */
function admin_url($url='')
{
    return base_url('admin/'.$url);
}