<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 15-Feb-17
 * Time: 2:23 PM
 */
$config = array(
    'admin'=>array('index','add','edit'),
    'catalog'=>array('index','add','edit','delete','delete_check')

);