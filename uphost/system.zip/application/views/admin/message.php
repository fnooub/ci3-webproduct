<div class="nNote nInformation hideit">
    <p><strong>Notice: </strong> <?php echo $message; ?></p>
</div>