<div id="footer">
    <div class="wrapper">Bản quyền © 2016-2017 thatweb.esy.es</div>
</div>