
<!-- The box-footer-->

<div id="footer_text"> <!-- The footer_text -->
    <strong>Học lập trình website online miễn phí.</strong>
    <p>Hướng dẫn xây dựng website bán hàng và thanh toán trực tuyến. </p>
    <p>Video hướng dẫn: <a href="https://www.youtube.com/watch?list=PLml7xFCO5p8rlpbV-9bDdz74cCXQCmeDk&amp;v=YRyzBuA_O4A">Xem video</a></p>
    <p>Website: <a href="http://hocphp.info">hocphp.info</a></p>
    <p>Fanpage: <a href="https://www.facebook.com/nobitacnt/">https://www.facebook.com/nobitacnt/</a></p>

</div><!-- End footer_text -->

<div id="footer_face">  <!-- The footer_face -->
    <a title="trên facebook" target="_blank" href="https://www.facebook.com/nobitacnt" rel="nofollow">
        <img alt="trên facebook" src="<?php echo public_url('site'); ?>/images/facebook.png">
    </a>

    <a title="trên twitter" target="_blank" href="https://twitter.com/" rel="nofollow">
        <img alt="trên twitter" src="<?php echo public_url('site'); ?>/images/twitter.png">
    </a>

    <a title="trên google" target="_blank" href="https://plus.google.com/" rel="nofollow">
        <img alt="trên google" src="<?php echo public_url('site'); ?>/images/google.png">
    </a>
</div><!-- End footer_face -->
<div class="clear"></div><!-- clear float --> 		        <!-- End box-footer -->
