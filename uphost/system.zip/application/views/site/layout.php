<html>
<head>
    <?php
    $this->load->view('site/head');
    ?>
</head>
<body>
<script>
    window.fbAsyncInit = function() {
        FB.init({
            appId      : '383289375379584',
            xfbml      : true,
            version    : 'v2.8'
        });
        FB.AppEvents.logPageView();
    };

    (function(d, s, id){
        var js, fjs = d.getElementsByTagName(s)[0];
        if (d.getElementById(id)) {return;}
        js = d.createElement(s); js.id = id;
        js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.8&appId=383289375379584";
        fjs.parentNode.insertBefore(js, fjs);
    }(document, 'script', 'facebook-jssdk'));
</script>
<a id="back_to_top" href="#">
    <img src="<?php echo public_url('site'); ?>/images/top.png">
</a>

<div class="wraper">
    <div class="header">
        <?php
        $this->load->view('site/header');
        ?>
    </div>
    <div id="container">
        <div class="left">
            <?php
            $this->load->view('site/left',$this->data);
            ?>
        </div>
        <?php if(isset($message)): ?>
                <h2><strong>Notice: </strong> <?php echo $message; ?></h2>
        <?php endif;?>
        <div class="content">
            <?php
            $this->load->view($temp,$this->data);
            ?>
        </div>
        <div class="right">
            <?php
            $this->load->view('site/right',$this->data);
            ?>
        </div>
        <div class="clear"></div>

    </div>
    <center>
        <img src="<?php echo public_url('site'); ?>/images/bank.png">
    </center>

    <div class="footer">
        <?php
        $this->load->view('site/footer');
        ?>
    </div>
</div>

</body>
</html>